mpackage = "Svof - dont install me as package"
